#!/usr/bin/env python3
"""
Minecraft Java Launcher (Python)
minecraft-launcher-lib tabanlı, Release 1.7+ destekli launcher.
"""
from __future__ import annotations

import argparse
import hashlib
import re
import subprocess
import sys
import uuid as _uuid
from pathlib import Path
from typing import Optional

import minecraft_launcher_lib

MIN_MINOR_VERSION = 7
DEFAULT_RAM_MB = 2048
DEFAULT_MINECRAFT_DIR = Path.home() / ".mc_launcher_py"
AUTHLIB_JAR_NAME = "authlib-injector.jar"


def _parse_version(version_id: str) -> Optional[int]:
    m = re.match(r"^1\.(\d+)", version_id)
    return int(m.group(1)) if m else None


def list_supported_versions() -> list[str]:
    try:
        versions = minecraft_launcher_lib.utils.get_version_list()
    except Exception as e:
        print(f"[HATA] Sürüm listesi alınamadı: {e}", file=sys.stderr)
        return []

    supported = []
    for v in versions:
        vid = v.get("id", "")
        vtype = v.get("type", "")
        if vtype != "release":
            continue
        minor = _parse_version(vid)
        if minor is not None and minor >= MIN_MINOR_VERSION:
            supported.append(vid)
    return supported


def ensure_authlib_injector(work_dir: Path) -> Path:
    authlib_dir = work_dir / "authlib"
    authlib_dir.mkdir(parents=True, exist_ok=True)
    jar_path = authlib_dir / AUTHLIB_JAR_NAME
    if not jar_path.exists():
        raise FileNotFoundError(
            f"authlib-injector.jar bulunamadı: {jar_path}\n"
            f"İndirme: https://github.com/yushijinhun/authlib-injector/releases"
        )
    return jar_path


def resolve_java(version_id: str, minecraft_dir: Path,
                 java_path: Optional[str] = None) -> Optional[str]:
    if java_path:
        return java_path

    try:
        runtime_path = minecraft_launcher_lib.runtime.get_executable_path(
            "java-runtime-gamma", str(minecraft_dir)
        )
        if runtime_path and Path(runtime_path).exists():
            return runtime_path
    except Exception:
        pass

    try:
        java_infos = minecraft_launcher_lib.java_utils.find_system_java_versions_information()
    except Exception:
        java_infos = []

    if java_infos:
        fallback = minecraft_launcher_lib.utils.get_java_executable()
        return java_infos[0].get("java_path") or fallback or "java"

    fallback = minecraft_launcher_lib.utils.get_java_executable()
    return fallback or "java"


def run(version_id: str, username: str, minecraft_dir: Path,
        ram_mb: int = DEFAULT_RAM_MB, skin_url: Optional[str] = None,
        java_path: Optional[str] = None, demo: bool = False) -> int:
    minecraft_dir.mkdir(parents=True, exist_ok=True)

    minor = _parse_version(version_id)
    if minor is None or minor < MIN_MINOR_VERSION:
        print(f"[HATA] Yalnızca Release 1.7+ destekleniyor. Verilen: {version_id}",
              file=sys.stderr)
        return 1

    authlib_jar = None
    if skin_url:
        try:
            authlib_jar = ensure_authlib_injector(minecraft_dir)
        except FileNotFoundError as e:
            print(f"[HATA] {e}", file=sys.stderr)
            return 1

    resolved_java = resolve_java(version_id, minecraft_dir, java_path)
    print(f"[BİLGİ] Java: {resolved_java}")
    print(f"[BİLGİ] Sürüm hazırlanıyor: {version_id}")

    callback = {
        "setStatus": lambda text: print(f"  {text}"),
        "setProgress": lambda value: None,
        "setMax": lambda value: None,
    }

    try:
        minecraft_launcher_lib.install.install_minecraft_version(
            version_id, str(minecraft_dir), callback=callback
        )
    except Exception as e:
        print(f"[HATA] İndirme başarısız: {e}", file=sys.stderr)
        return 1

    jvm_args = [
        f"-Xmx{ram_mb}M",
        f"-Xms{max(512, ram_mb // 2)}M",
        "-Dfile.encoding=UTF-8",
    ]
    if authlib_jar and skin_url:
        jvm_args.append(f"-javaagent:{authlib_jar}={skin_url}")
        jvm_args.append("-Dauthlibinjector.noLogFile")
        print(f"[BİLGİ] authlib-injector: {skin_url}")

    digest = bytearray(hashlib.md5(f"OfflinePlayer:{username}".encode()).digest())
    digest[6] = (digest[6] & 0x0F) | 0x30
    digest[8] = (digest[8] & 0x3F) | 0x80
    offline_uuid = str(_uuid.UUID(bytes=bytes(digest))).replace("-", "")

    options = {
        "username": username,
        "uuid": offline_uuid,
        "token": "0",
        "executablePath": resolved_java,
        "jvmArguments": jvm_args,
        "launcherName": "MC Launcher Py",
        "launcherVersion": "1.0",
        "demo": demo,
        "gameDirectory": str(minecraft_dir / "game"),
    }

    try:
        command = minecraft_launcher_lib.command.get_minecraft_command(
            version_id, str(minecraft_dir), options
        )
    except Exception as e:
        print(f"[HATA] Komut oluşturulamadı: {e}", file=sys.stderr)
        return 1

    print(f"[BİLGİ] Başlatılıyor: {version_id} ({username})")
    try:
        process = subprocess.Popen(
            command, cwd=str(minecraft_dir / "game"),
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, encoding="utf-8", errors="replace",
        )
    except FileNotFoundError:
        print(f"[HATA] Java bulunamadı: {resolved_java}", file=sys.stderr)
        return 1

    if process.stdout:
        for line in process.stdout:
            print(line.rstrip())
    return process.wait()


def main() -> int:
    p = argparse.ArgumentParser(description="Python Minecraft Launcher")
    p.add_argument("--version", "-v")
    p.add_argument("--username", "-u", default="Player")
    p.add_argument("--skin-url", default=None)
    p.add_argument("--java-path", default=None)
    p.add_argument("--ram", type=int, default=DEFAULT_RAM_MB)
    p.add_argument("--dir", default=str(DEFAULT_MINECRAFT_DIR))
    p.add_argument("--demo", action="store_true")
    p.add_argument("--list-versions", action="store_true")
    args = p.parse_args()

    if args.list_versions:
        for v in list_supported_versions():
            print(v)
        return 0
    if not args.version:
        p.error("--version zorunlu (veya --list-versions)")
    return run(args.version, args.username, Path(args.dir),
               args.ram, args.skin_url, args.java_path, args.demo)


if __name__ == "__main__":
    sys.exit(main())
