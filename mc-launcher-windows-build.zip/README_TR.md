# Minecraft Launcher Python — Windows `.exe` derleme rehberi

Bu proje Windows bilgisayar gerektirmeden GitHub Actions üzerinde derlenir. GitHub'ın geçici Windows makinesi `launcher.py` dosyasını PyInstaller ile tek bir `MC-Launcher-Py.exe` dosyasına çevirir. Derleme tamamlanınca EXE, GitHub Actions **artifact** olarak indirilebilir.

## Klasör yapısı

```text
.
├── launcher.py
├── requirements.txt
└── .github/
    └── workflows/
        └── build-windows.yml
```

## Android tablet ile kurulum

1. Tarayıcıdan [github.com](https://github.com) adresini açıp hesabınıza giriş yapın.
2. Yeni bir repository oluşturun. Örneğin adı `mc-launcher-py` olsun. Repository'yi **Private** bırakabilirsiniz.
3. Repository sayfasında **Add file → Create new file** seçeneğini kullanın.
4. İlk dosya olarak `launcher.py` oluşturun ve bu projedeki Python kodunu yapıştırıp **Commit changes** ile kaydedin.
5. Aynı şekilde kök dizinde `requirements.txt` oluşturun ve şu satırı ekleyin:

   ```text
   minecraft-launcher-lib
   ```

6. İkinci bir dosya oluştururken dosya adını doğrudan `.github/workflows/build-windows.yml` yazın. Bu dosyaya bu paketteki workflow içeriğini yapıştırın ve kaydedin.
7. Repository'de **Actions** sekmesine girin. `Windows EXE oluştur` workflow'unu açın.
8. Otomatik çalışmadıysa **Run workflow → Run workflow** düğmesine basın.
9. İş yeşil tik ile tamamlanınca aynı sayfadaki **Artifacts** bölümünden `MC-Launcher-Py-windows-x64` ZIP dosyasını indirin.
10. ZIP'i Android tablette açın. İçindeki `MC-Launcher-Py.exe` dosyasını Windows bilgisayara aktarın.

`main` dalına Python veya workflow dosyası gönderildiğinde derleme otomatik olarak tekrar çalışır. İsterseniz yalnızca manuel çalıştırma için workflow içindeki `push:` bölümünü silebilirsiniz.

## Workflow ne yapıyor?

- `windows-latest` üzerinde çalışır; bu nedenle EXE gerçekten Windows x64 için üretilir.
- Python 3.11 kurar.
- `requirements.txt` içindeki `minecraft-launcher-lib` paketini yükler.
- PyInstaller'ı kurar.
- `--onefile` ile tek EXE üretir.
- `--collect-all minecraft_launcher_lib` ile kütüphanenin paket içindeki modül ve veri dosyalarını toplamaya çalışır.
- EXE'yi 30 gün süreyle Actions artifact'i olarak saklar.

## Windows'ta çalıştırma

Bu program grafik arayüzlü bir uygulama değildir; konsol/Komut İstemi penceresinde çalışır. Örnek kullanım:

```powershell
.\MC-Launcher-Py.exe --list-versions
.\MC-Launcher-Py.exe --version 1.20.1 --username Player --ram 4096
```

İlk çalıştırmada Minecraft dosyaları internetten indirilir. Bu yüzden EXE'yi çalıştıran Windows bilgisayarın internet erişimi olmalıdır.

## Önemli çalışma koşulları

- EXE'yi çalıştıran bilgisayarda uygun Java bulunmalıdır. Program önce Minecraft runtime'ını, sonra sistem Java'sını arar. Java bulunamazsa `Java bulunamadı` hatası verir.
- `--skin-url` kullanılırsa `authlib-injector.jar` dosyasının ilgili Minecraft klasöründeki `authlib` dizininde bulunması gerekir. Bu dosya EXE'nin içine dahil edilmez.
- Minecraft sürüm dosyaları, kütüphaneler ve oyun klasörü ilk çalıştırmada kullanıcının `--dir` ile verdiği dizine; varsayılan olarak Windows kullanıcı profilindeki `.mc_launcher_py` dizinine indirilir.
- Bu launcher çevrimdışı kullanıcı adı (`OfflinePlayer`) mantığı kullanır; resmi Microsoft hesap girişi eklenmiş bir launcher değildir. Telif, hesap ve sunucu kurallarına uygun kullanın.
- GitHub Actions yalnızca derleme ortamıdır. Minecraft dosyalarını veya `authlib-injector.jar` dosyasını repository'ye koymak gerekmez.
- GitHub'dan indirilen EXE Windows SmartScreen tarafından uyarıyla karşılanabilir; bu, dosyanın imzalı bir Windows uygulaması olmadığı anlamına gelir. Kaynak kodu ve Actions loglarını kontrol etmeden çalıştırmayın.

## Sorun giderme

### `ModuleNotFoundError` veya açılır açılmaz kapanma

Actions loglarında `Build EXE` adımını açın. Çoğu durumda `--collect-all minecraft_launcher_lib` yeterlidir. Yeni bir alt modül eksik görünürse workflow'daki PyInstaller komutuna örneğin şu seçeneği ekleyebilirsiniz:

```text
--hidden-import minecraft_launcher_lib.runtime
```

### Artifact görünmüyor

Workflow run'ının kırmızı değil yeşil tamamlandığını kontrol edin. Kırmızıysa **Build EXE** adımının logunu açın. `requirements.txt` ve `launcher.py` dosyalarının repository kökünde olduğundan emin olun.

### EXE açılıyor ama Java hatası veriyor

Bu bir derleme hatası değildir. Windows'a uygun Java kurun veya tam yolu açıkça verin:

```powershell
.\MC-Launcher-Py.exe --version 1.20.1 --java-path "C:\Program Files\Java\jdk-21\bin\java.exe"
```

Java sürümü Minecraft sürümüne uygun olmalıdır.

## Yerel derleme gerekmez

Android tabletinizde Python, PyInstaller veya Windows kurulmasına gerek yoktur. Tablet yalnızca GitHub dosyalarını düzenlemek, workflow'u başlatmak ve artifact ZIP'ini indirmek için kullanılır.
